"""
Configuration module for environment variables and application settings.
Centralized settings for database, security, AWS, and application behavior.
"""

import os
import secrets
from typing import Dict, List, Optional
from urllib.parse import urlparse

from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# --- Environment Detection ---
def is_lambda_env() -> bool:
    """Check if running in AWS Lambda environment"""
    return bool(os.environ.get('AWS_LAMBDA_FUNCTION_NAME'))

def is_development_env() -> bool:
    """Check if running in development environment"""
    env = os.getenv("ENVIRONMENT", "").lower()
    return env in ["development", "dev", "local", "test"]

# --- Constants ---
DEFAULT_ENVIRONMENT = "development" if is_development_env() else "production"
DEFAULT_LOG_LEVEL = "DEBUG" if is_development_env() else "INFO"
DEFAULT_AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
DEFAULT_VERSION = "1.0.0"

MAX_FILE_SIZE_MB = 100
MAX_FILE_SIZE = MAX_FILE_SIZE_MB * 1024 * 1024  # bytes

# --- Application Settings ---
ENVIRONMENT = os.getenv("ENVIRONMENT", DEFAULT_ENVIRONMENT)
DEBUG: bool = is_development_env()
LOG_LEVEL = os.getenv("LOG_LEVEL", DEFAULT_LOG_LEVEL)
VERSION = os.getenv("APP_VERSION", DEFAULT_VERSION)

# --- AWS Lambda Specific Settings ---
IS_LAMBDA = is_lambda_env()
LAMBDA_FUNCTION_NAME = os.getenv("AWS_LAMBDA_FUNCTION_NAME", "")
LAMBDA_FUNCTION_VERSION = os.getenv("AWS_LAMBDA_FUNCTION_VERSION", "")

# --- Database Configuration ---
DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL:
    raise ValueError("DATABASE_URL environment variable is required")

parsed_url = urlparse(DATABASE_URL)

# --- Extract query params ---
query_params: Dict[str, str] = {}
if parsed_url.query:
    query_params = dict(
        param.split("=", 1) for param in parsed_url.query.split("&") if "=" in param
    )

# --- Handle sslmode separately ---
ssl_mode: str = query_params.pop("sslmode", "prefer")

if parsed_url.hostname in {"localhost", "127.0.0.1", "postgres", "redis"}:
    ssl_mode = os.getenv("SSL_MODE", "SSL_MODE")
elif ENVIRONMENT == "development":
    ssl_mode = os.getenv("SSL_MODE", "SSL_MODE")

# --- Reconstruct DB URL without sslmode ---
new_query = "&".join([f"{k}={v}" for k, v in query_params.items()])
clean_url = parsed_url._replace(query=new_query or None).geturl()

# --- Ensure correct driver ---
if clean_url.startswith("postgres://"):
    clean_url = clean_url.replace("postgres://", "postgresql+asyncpg://", 1)
elif clean_url.startswith("postgresql://"):
    clean_url = clean_url.replace("postgresql://", "postgresql+asyncpg://", 1)
elif not clean_url.startswith("postgresql+asyncpg://"):
    clean_url = "postgresql+asyncpg://" + clean_url.split("://", 1)[1]

SQLALCHEMY_DATABASE_URL = clean_url
SSL_MODE = ssl_mode

# --- SQLAlchemy engine settings ---
POOL_SIZE = int(os.getenv("DB_POOL_SIZE", 5))
MAX_OVERFLOW = int(os.getenv("DB_MAX_OVERFLOW", 10))
POOL_TIMEOUT = int(os.getenv("DB_POOL_TIMEOUT", 30))
POOL_RECYCLE = int(os.getenv("DB_POOL_RECYCLE", 1800))

# --- AWS / S3 Configuration ---
AWS_ACCESS_KEY_ID: Optional[str] = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY: Optional[str] = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION = os.getenv("AWS_REGION", DEFAULT_AWS_REGION)
S3_BUCKET_NAME: Optional[str] = os.getenv("S3_BUCKET_NAME")

# --- Security / JWT Configuration ---
SECRET_KEY = os.getenv("SECRET_KEY", secrets.token_urlsafe(32))
ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", 60))
REFRESH_TOKEN_EXPIRE_DAYS = int(os.getenv("REFRESH_TOKEN_EXPIRE_DAYS", 7))

# --- File Upload Settings ---
ALLOWED_EXTENSIONS: Dict[str, List[str]] = {
    "image": ["jpg", "jpeg", "png", "gif", "webp"],
    "document": ["pdf", "doc", "docx", "txt", "csv", "xlsx"],
    "video": ["mp4", "mov", "avi", "mkv"],
    "audio": ["mp3", "wav", "ogg"],
}

# ---CORS / Origins ---
ALLOWED_ORIGINS: List[str] = [
    "http://localhost:3000",
    "http://localhost:5173",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:5173",
]

# --- Document Scoring / Chunking ---
MAX_CONTENT_LENGTH_FOR_SCORING = 1024 * 1024  # 1 MB
CHUNK_SIZE = 8192  # 8 KB

# --- Redis Configuration ---
REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", "")
REDIS_DB = os.getenv("REDIS_DB", "")
REDIS_SSL = os.getenv("REDIS_SSL", "false").lower() == "true"
REDIS_MAX_CONNECTIONS = int(os.getenv("REDIS_MAX_CONNECTIONS", 10))
REDIS_TIMEOUT = int(os.getenv("REDIS_TIMEOUT", 5))

# --- Cache TTLs (in seconds) ---
CACHE_TTL_TOKEN = int(os.getenv("CACHE_TTL_TOKEN", 300))  # 5 minutes
CACHE_TTL_USER = int(os.getenv("CACHE_TTL_USER", 3600))   # 1 hour
CACHE_TTL_FILE = int(os.getenv("CACHE_TTL_FILE", 1800))   # 30 minutes


PASSWORD_RESET_TOKEN_EXPIRE_MINUTES = int(os.getenv("PASSWORD_RESET_TOKEN_EXPIRE_MINUTES", 30))
PASSWORD_RESET_BASE_URL = os.getenv("PASSWORD_RESET_BASE_URL", "https://yourapp.com/reset-password")

# Email configuration
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", 587))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
FROM_EMAIL = os.getenv("FROM_EMAIL", "noreply@yourapp.com")
